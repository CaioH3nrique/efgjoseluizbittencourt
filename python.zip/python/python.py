nome = input('qual o seu nome?')
idade = input('qual é sua idade?')
cidade = input('qual a sua cidade?')

print(f"boas vindas {nome}, sua idade é {idade} anos e você é de {cidade}.")